%% ellipseFit4HC_EXAMPLE
% (c) Viktor Witkovsky (witkovsky@savba.sk)
% Ver.: 31-Jul-2014 18:27:32

clear

%% GENERATE the uncorrelated measurements: x and y 
%  Feel free to experiment with the setting parameters

alpha0true = 0;                             % x-center (offset x)
beta0true  = 0;                             % y-center (offset x)
alpha1true = 1;                             % x-amplitude
beta1true  = 1;                             % y-amplitude
phi0true   = 0;                             % phase offset

sigma = 0.001;                          % std of x and y independent errors
n = 500;                               % number of measurements points
cycles = 1;                             % measurement interval,  # cycles
phitrue = cycles*(2*pi)*sort(rand(n,1));    % true phases phi_i

% true values:  X and Y
Xmean = @(t) alpha0true + alpha1true * cos(t);
Ymean = @(t) beta0true + beta1true * sin(t + phi0true);

% measurements:  X + error, Y + error,
x = Xmean(phitrue) + sigma * randn(size(phitrue));
y = Ymean(phitrue) + sigma * randn(size(phitrue));

%% Fit the ellipse based on measured data

options.alpha = 0.05;
options.correlation = 0;
options.displconst = 633.3/(4*pi);
options.displunit = 'nanometer [nm]';
result = ellipseFit4HC(x,y,options);

disp(result)

%% Display statistics of the fitted displacements (!! Table with n rows !!)

TABLE1 = result.TABLE_EllipsePars;
TABLE2 = result.TABLE_Displacements;

disp(TABLE2)
disp(['Displacement unit: ' result.Displacement_unit])

%% Plot the stat. uncertainty of displacement

displ_std = result.Displacement_std;

figure
plot(phitrue, displ_std)
xlabel('phi');
ylabel(['Statistical uncertainty of displacement, ',result.Displacement_unit]);
title(['Statistical Uncertainty: Min: ', ...
    num2str(result.Displacement_std_min), ', Max: ', ...
    num2str(result.Displacement_std_max) ]);

%% Plot the displacements with expanded uncertainties

displ_fit = result.Displacement_fit;
const = result.Displacement_const;
displ_true = const*phitrue;
displ_res = displ_fit - displ_true;
ix = (result.phi_fit-phitrue) < -1;
displ_res(ix) = displ_res(ix) + 2*pi*const;

figure
plot(displ_true, displ_res ,'o')
hold 
plot(displ_true, 2*displ_std ,'r-')
plot(displ_true, -2*displ_std ,'r-')
grid
xlabel('True displacement');
ylabel('Displacement Residuals');
title('Expanded Uncertainty of Fitted Displacement');

%% Plot the X residuals with the expanded uncertainties

figure
plot(phitrue,result.x_res_fit,'.')
hold
plot(phitrue,2*result.x_res_std,'r-')
plot(phitrue,-2*result.x_res_std,'r-')
grid
xlabel('True phi');
ylabel('x residuals');
title('Expanded Uncertainty of Fitted X Residuals');


%% Plot the Y residuals with the expanded uncertainties

figure
plot(phitrue,result.y_res_fit,'.')
hold
plot(phitrue,2*result.y_res_std,'r-')
plot(phitrue,-2*result.y_res_std,'r-')
grid
xlabel('True phi');
ylabel('y residuals');
title('Expanded Uncertainty of Fitted Y Residuals');


%% CORRELATED MEASUREMENTS

clear

%% GENERATE the correlated measurements: x and y 
alpha0true = 0;                             % x-center (offset x)
beta0true  = 0;                             % y-center (offset x)
alpha1true = 1;                             % x-amplitude
beta1true  = 0.98;                             % y-amplitude
phi0true   = pi/10;                         % phase offset

sigma = 0.005;                           % std of x and y independent errors
n = 1000;                               % number of measurements points
cycles = 1;                             % measurement interval,  # cycles
phitrue = cycles*(2*pi)*sort(rand(n,1));    % true phases phi_i

% true values:  X and Y
Xmean = @(t) alpha0true + alpha1true * cos(t);
Ymean = @(t) beta0true + beta1true * sin(t + phi0true);

rho = 0.9;
err = mvnrnd([0 0],sigma^2*[1 rho; rho 1],n);

% AR errors + correlated x and y
% rhoAR = -.99995;
% err = sigma*filter(1,[1 rhoAR],mvnrnd([0 0],[1 rho; rho 1],n));

x = Xmean(phitrue) + err(:,1);
y = Ymean(phitrue) + err(:,2);

%% Fit the ellipse based on measured data

options.alpha = 0.05;
options.correlation = rho; % Set the true correlation (assumed to be known)
options.displconst = 633.3/(4*pi);
options.displunit = 'nanometer [nm]';
result = ellipseFit4HC(x,y,options);

disp(result)

%% Display statistics of the fitted displacements (!! Table with n rows !!)

TABLE1 = result.TABLE_EllipsePars;
TABLE2 = result.TABLE_Displacements;

disp(TABLE2)
disp(['Displacement unit: ' result.Displacement_unit])

%% Plot the stat. uncertainty of displacement

displ_std = result.Displacement_std;

figure
plot(phitrue, displ_std)
xlabel('phi');
ylabel(['Statistical uncertainty of displacement, ',result.Displacement_unit]);
title(['Statistical Uncertainty: Min: ', ...
    num2str(result.Displacement_std_min), ', Max: ', ...
    num2str(result.Displacement_std_max) ]);

%% Plot the displacements with expanded uncertainties

displ_fit = result.Displacement_fit;
const = result.Displacement_const;
displ_true = const*phitrue;
displ_res = displ_fit - displ_true;
ix = (result.phi_fit-phitrue) < -1;
displ_res(ix) = displ_res(ix) + 2*pi*const;

figure
plot(displ_true, displ_res ,'o')
hold 
plot(displ_true, 2*displ_std ,'r-')
plot(displ_true, -2*displ_std ,'r-')
grid
xlabel('True displacement');
ylabel('Displacement Residuals');
title('Expanded Uncertainty of Fitted Displacement');

%% Plot the X residuals with the expanded uncertainties

figure
plot(phitrue,result.x_res_fit,'.')
hold
plot(phitrue,2*result.x_res_std,'r-')
plot(phitrue,-2*result.x_res_std,'r-')
grid
xlabel('True phi');
ylabel('x residuals');
title('Expanded Uncertainty of Fitted X Residuals');


%% Plot the Y residuals with the expanded uncertainties

figure
plot(phitrue,result.y_res_fit,'.')
hold
plot(phitrue,2*result.y_res_std,'r-')
plot(phitrue,-2*result.y_res_std,'r-')
grid
xlabel('True phi');
ylabel('y residuals');
title('Expanded Uncertainty of Fitted Y Residuals');
