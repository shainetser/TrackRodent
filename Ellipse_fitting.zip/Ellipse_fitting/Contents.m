% Ellipse fitting
%
% fitellipse  - least squares ellipse fit
% plotellipse - plot fitted ellipses